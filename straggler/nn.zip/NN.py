import tensorflow as tf
import numpy as np

def create_NN(dim, ):

